# Kunci API — oleh Edymart Kerupuk

Aplikasi Android mandiri untuk mengambil, mengetes, melihat, dan menyimpan kunci API Gemini dari Google AI Studio.

## Cara pakai aplikasi
1. Tekan **Buka Google AI Studio**, login, lalu buat kunci (Create API key).
2. Salin kuncinya, balik ke aplikasi, tekan **Tempel dari clipboard**.
3. Tekan **Tes & simpan**. Kalau valid, kunci tersimpan di HP.
4. Tekan **Lihat kunci** kapan saja untuk melihat kunci yang tersimpan, atau **Salin kunci** untuk dipakai di aplikasi lain.

## Cara build lewat GitHub (dari HP)
1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk folder `.github` dan file `app/tetap.keystore`).
2. Buka tab **Actions**, pilih **Build APK**, lalu tekan **Run workflow**.
3. Setelah selesai, unduh artifact **KunciAPI-debug**, ekstrak zip, lalu install `app-debug.apk`.

## Update tanpa hapus aplikasi lama
- Semua versi ditandatangani dengan `app/tetap.keystore` yang sama, dan nomor versi naik otomatis tiap build di GitHub. Jadi APK baru bisa langsung diinstal menimpa yang lama, kunci tersimpan tetap aman.
- Jangan ganti atau hilangkan file `tetap.keystore`. Kalau hilang, update tidak bisa lagi menimpa versi lama.
