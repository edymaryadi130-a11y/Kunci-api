# Kunci API

Aplikasi Android mandiri untuk mengambil, mengetes, dan menyimpan kunci API Gemini dari Google AI Studio.

## Cara pakai aplikasi
1. Tekan **Buka Google AI Studio**, login, lalu buat kunci (Create API key).
2. Salin kuncinya, balik ke aplikasi, tekan **Tempel dari clipboard**.
3. Tekan **Tes & simpan**. Kalau valid, kunci tersimpan di HP.

## Cara build lewat GitHub (dari HP)
1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions**, pilih workflow **Build APK**, tekan **Run workflow**.
3. Setelah selesai, buka run-nya, unduh artifact **KunciAPI-debug**, ekstrak zip, lalu install `app-debug.apk`.
