package com.ed.kunciapi

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var kolomKunci: EditText
    private lateinit var status: TextView
    private lateinit var tombolTes: Button

    private val prefs by lazy { getSharedPreferences("kunci_api", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buatTampilan())
        prefs.getString("api_key", null)?.let {
            kolomKunci.setText(it)
            tampilStatus("Kunci tersimpan di HP ini: ${samarkan(it)}", Color.parseColor("#2E7D32"))
        }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun tombol(teks: String, warna: String, klik: () -> Unit) = Button(this).apply {
        text = teks
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.parseColor(warna))
        setOnClickListener { klik() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) }
    }

    private fun buatTampilan(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Kunci API Gemini"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#1A1A1A"))
        })
        root.addView(TextView(this).apply {
            text = "Ambil kunci gratis dari Google AI Studio, tes, lalu simpan di HP."
            textSize = 14f
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, dp(4), 0, dp(16))
        })

        root.addView(langkah("1. Buka Google AI Studio, login, lalu buat kunci (Create API key)."))
        root.addView(tombol("Buka Google AI Studio", "#1A73E8") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        })

        root.addView(langkah("2. Salin kuncinya, balik ke sini, lalu tempel.").apply {
            setPadding(0, dp(20), 0, 0)
        })
        kolomKunci = EditText(this).apply {
            hint = "AIza..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
        }
        root.addView(kolomKunci)
        root.addView(tombol("Tempel dari clipboard", "#5F6368") { tempel() })

        root.addView(langkah("3. Tes kuncinya, kalau valid langsung disimpan.").apply {
            setPadding(0, dp(20), 0, 0)
        })
        tombolTes = tombol("Tes & simpan", "#2E7D32") { tesDanSimpan() }
        root.addView(tombolTes)

        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.START
            setPadding(0, dp(16), 0, dp(8))
        }
        root.addView(status)

        root.addView(tombol("Salin kunci", "#5F6368") { salin() })
        root.addView(tombol("Hapus kunci dari HP", "#C62828") { hapus() })

        root.addView(TextView(this).apply {
            text = "Kunci hanya disimpan di HP ini dan dikirim ke Google saat tes. " +
                "Jangan bagikan kuncimu ke orang lain atau upload ke GitHub."
            textSize = 12f
            setTextColor(Color.parseColor("#777777"))
            setPadding(0, dp(20), 0, 0)
        })

        return ScrollView(this).apply { addView(root) }
    }

    private fun langkah(teks: String) = TextView(this).apply {
        text = teks
        textSize = 15f
        setTextColor(Color.parseColor("#222222"))
        setPadding(0, 0, 0, dp(4))
    }

    private fun tempel() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val teks = cm.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.coerceToText(this)?.toString()?.trim().orEmpty()
        if (teks.isEmpty()) {
            Toast.makeText(this, "Clipboard kosong", Toast.LENGTH_SHORT).show()
        } else {
            kolomKunci.setText(teks)
        }
    }

    private fun tesDanSimpan() {
        val kunci = kolomKunci.text.toString().trim()
        if (kunci.isEmpty()) {
            tampilStatus("Isi dulu kuncinya.", Color.parseColor("#C62828"))
            return
        }
        tombolTes.isEnabled = false
        tampilStatus("Mengetes kunci...", Color.parseColor("#555555"))

        thread {
            val hasil = try {
                val koneksi = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1")
                    .openConnection() as HttpURLConnection
                koneksi.setRequestProperty("x-goog-api-key", kunci)
                koneksi.connectTimeout = 15000
                koneksi.readTimeout = 15000
                val kode = koneksi.responseCode
                koneksi.disconnect()
                kode
            } catch (e: Exception) {
                -1
            }

            runOnUiThread {
                tombolTes.isEnabled = true
                when (hasil) {
                    200 -> {
                        prefs.edit().putString("api_key", kunci).apply()
                        tampilStatus("Kunci valid dan sudah disimpan: ${samarkan(kunci)}", Color.parseColor("#2E7D32"))
                    }
                    400, 401, 403 -> tampilStatus(
                        "Kunci ditolak Google (kode $hasil). Cek lagi apakah tersalin lengkap.",
                        Color.parseColor("#C62828")
                    )
                    -1 -> tampilStatus(
                        "Tidak bisa terhubung. Cek koneksi internet lalu coba lagi.",
                        Color.parseColor("#C62828")
                    )
                    else -> tampilStatus("Respons tak terduga dari Google (kode $hasil).", Color.parseColor("#C62828"))
                }
            }
        }
    }

    private fun salin() {
        val kunci = kolomKunci.text.toString().trim()
        if (kunci.isEmpty()) {
            Toast.makeText(this, "Belum ada kunci", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Kunci API", kunci))
        Toast.makeText(this, "Kunci disalin", Toast.LENGTH_SHORT).show()
    }

    private fun hapus() {
        prefs.edit().remove("api_key").apply()
        kolomKunci.setText("")
        tampilStatus("Kunci dihapus dari HP.", Color.parseColor("#555555"))
    }

    private fun tampilStatus(teks: String, warna: Int) {
        status.text = teks
        status.setTextColor(warna)
    }

    private fun samarkan(k: String) =
        if (k.length > 8) k.take(4) + "..." + k.takeLast(4) else "****"
}
