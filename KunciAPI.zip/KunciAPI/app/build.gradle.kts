plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ed.kunciapi"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ed.kunciapi"
        minSdk = 24
        targetSdk = 34
        // Naik otomatis tiap build di GitHub (nomor run), jadi APK baru bisa menimpa yang lama
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.1"
    }

    // Tanda tangan tetap: wajib sama di setiap versi agar update tidak gagal "aplikasi tidak terinstal"
    signingConfigs {
        create("tetap") {
            storeFile = file("tetap.keystore")
            storePassword = "edymart123"
            keyAlias = "edymart"
            keyPassword = "edymart123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("tetap")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("tetap")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
}
